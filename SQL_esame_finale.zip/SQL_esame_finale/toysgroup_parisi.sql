- Crea e popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate).

CREATE SCHEMA ToysGroup;

CREATE TABLE toysgroup.prodotto (
    id_prodotto INT PRIMARY KEY AUTO_INCREMENT,
    nome_prodotto VARCHAR(100),
    categoria VARCHAR(100),
    prezzo_unità FLOAT
);

INSERT INTO prodotto (nome_prodotto, categoria, prezzo_unità)
VALUES
  ('Puzzle Magico', 'Giochi da Tavolo', 19.99),
  ('Astronave Galattica', 'Giocattoli Elettronici', 29.99),
  ('Bambole Incantate', 'Bambole', 14.99),
  ('Set da Pittura Artistico', 'Giochi Creativi', 22.99),
  ('Robot Avventuroso', 'Giochi Elettronici', 39.99),
  ('Cucina Magica', 'Giochi di Ruolo', 34.99),
  ('Dinosauri Esploratori', 'Giocattoli Educativi', 18.99),
  ('Peluche Magico', 'Peluche', 12.99),
  ('Macchina da Corsa Velocissima', 'Giochi Motori', 27.99),
  ('Kit di Costruzione Spaziale', 'Giochi Creativi', 25.99),
  ('Animali della Fattoria', 'Giocattoli Educativi', 16.99),
  ('Spada Leggendaria', 'Giochi di Ruolo', 19.99),
  ('Trenino Colorato', 'Giochi Motori', 14.99),
  ('Trasformatori Robotici', 'Giochi Elettronici', 32.99),
  ('Bicicletta Magica', 'Giochi Motori', 49.99),
  ('Puzzle 3D Architetturale', 'Giochi da Tavolo', 23.99),
  ('Kit di Modellismo Navale', 'Giochi Creativi', 36.99),
  ('Kit di Scienza Esplorativa', 'Giocattoli Educativi', 28.99),
  ('Orsetto Coccole', 'Peluche', 9.99),
  ('Aliante Volante', 'Giochi Motori', 17.99);

SELECT 
    *
FROM
    vendite;
    
 CREATE TABLE toysgroup.regione (
    id_regione VARCHAR(5) PRIMARY KEY,
    nome_regione VARCHAR(100)
);

INSERT INTO regione (id_regione, nome_regione)
VALUES
  ('R01', 'Abruzzo'),
  ('R02', 'Basilicata'),
  ('R03', 'Calabria'),
  ('R04', 'Campania'),
  ('R05', 'Emilia-Romagna'),
  ('R06', 'Friuli-Venezia Giulia'),
  ('R07', 'Lazio'),
  ('R08', 'Liguria'),
  ('R09', 'Lombardia'),
  ('R10', 'Marche'),
  ('R11', 'Molise'),
  ('R12', 'Piemonte'),
  ('R13', 'Puglia'),
  ('R14', 'Sardegna'),
  ('R15', 'Sicilia'),
  ('R16', 'Toscana'),
  ('R17', 'Trentino-Alto Adige'),
  ('R18', 'Umbria'),
  ('R19', 'Valle d\'Aosta'),
  ('R20', 'Veneto');

CREATE TABLE toysgroup.vendite (
    id_vendite VARCHAR(5) PRIMARY KEY,
    id_prodotto INT,
    FOREIGN KEY (id_prodotto)
        REFERENCES prodotto (id_prodotto),
    id_regione VARCHAR(5),
    FOREIGN KEY (id_regione)
        REFERENCES regione (id_regione),
    quantità_venduta INT,
    data DATE,
    tot_vendite INT
);

INSERT INTO vendite (id_vendite, id_prodotto, id_regione, quantità_venduta, data, tot_vendite)
VALUES
  ('V001', 1, 'R01', 50, '2024-02-24', 999.50),
  ('V002', 3, 'R03', 30, '2024-02-25', 449.70),
  ('V003', 5, 'R05', 20, '2024-02-26', 799.80),
  ('V004', 8, 'R08', 40, '2024-02-27', 519.60),
  ('V005', 12, 'R12', 25, '2024-02-28', 899.75),
  ('V006', 15, 'R15', 35, '2024-02-29', 699.65),
  ('V007', 18, 'R18', 15, '2024-03-01', 299.85),
  ('V008', 20, 'R20', 28, '2024-03-02', 799.72),
  ('V009', 2, 'R02', 18, '2024-03-03', 239.82),
  ('V010', 7, 'R07', 22, '2024-03-04', 669.78),
  ('V011', 10, 'R10', 33, '2024-03-05', 429.67),
  ('V012', 14, 'R14', 27, '2024-03-06', 539.73),
  ('V013', 17, 'R17', 10, '2024-03-07', 149.90),
  ('V014', 19, 'R19', 15, '2024-03-08', 349.85),
  ('V015', 4, 'R04', 40, '2024-03-09', 799.60),
  ('V016', 6, 'R06', 28, '2024-03-10', 499.72),
  ('V017', 9, 'R09', 21, '2024-03-11', 349.79),
  ('V018', 11, 'R11', 12, '2024-03-12', 179.88),
  ('V019', 13, 'R13', 16, '2024-03-13', 269.84),
  ('V020', 16, 'R16', 24, '2024-03-14', 599.76);

alter table vendite modify column tot_vendite float;

REPLACE INTO vendite (id_vendite, id_prodotto, id_regione, quantità_venduta, data, tot_vendite)
VALUES
  ('V001', 1, 'R01', 50, '2024-02-24', 999.50),
  ('V002', 3, 'R03', 30, '2024-02-25', 449.70),
  ('V003', 5, 'R05', 20, '2024-02-26', 799.80),
  ('V004', 8, 'R08', 40, '2024-02-27', 519.60),
  ('V005', 12, 'R12', 25, '2024-02-28', 899.75),
  ('V006', 15, 'R15', 35, '2024-02-29', 699.65),
  ('V007', 18, 'R18', 15, '2024-03-01', 299.85),
  ('V008', 20, 'R20', 28, '2024-03-02', 799.72),
  ('V009', 2, 'R02', 18, '2024-03-03', 239.82),
  ('V010', 7, 'R07', 22, '2024-03-04', 669.78),
  ('V011', 10, 'R10', 33, '2024-03-05', 429.67),
  ('V012', 14, 'R14', 27, '2024-03-06', 539.73),
  ('V013', 17, 'R17', 10, '2024-03-07', 149.90),
  ('V014', 19, 'R19', 15, '2024-03-08', 349.85),
  ('V015', 4, 'R04', 40, '2024-03-09', 799.60),
  ('V016', 6, 'R06', 28, '2024-03-10', 499.72),
  ('V017', 9, 'R09', 21, '2024-03-11', 349.79),
  ('V018', 11, 'R11', 12, '2024-03-12', 179.88),
  ('V019', 13, 'R13', 16, '2024-03-13', 269.84),
  ('V020', 16, 'R16', 24, '2024-03-14', 599.76);

- 1. Verificare che i campi definiti come PK siano univoci;

SELECT 
    id_prodotto, COUNT(*)
FROM
    prodotto
GROUP BY id_prodotto
HAVING COUNT(*) > 1;

SELECT 
    id_regione, COUNT(*)
FROM
    regione
GROUP BY id_regione
HAVING COUNT(*) > 1;

SELECT 
    id_vendite, COUNT(*)
FROM
    vendite
GROUP BY id_vendite
HAVING COUNT(*) > 1;


- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno;

select 
    prodotto.id_prodotto,
    prodotto.nome_prodotto,
    YEAR(vendite.data) AS anno,
    SUM(vendite.tot_vendite) AS fatturato_totale 
FROM
    vendite
        JOIN
    prodotto ON vendite.id_prodotto = prodotto.id_prodotto
GROUP BY prodotto.id_prodotto , YEAR(vendite.data)
ORDER BY prodotto.id_prodotto , anno;


- 3. Esporre il fatturato totale per stato per giorno (la base dati ha solo il 2024 come anno). Ordina il risultato per data e per fatturato decrescente;

SELECT 
    regione.id_regione,
    regione.nome_regione,
    date(vendite.data) AS data_vendita,
    SUM(vendite.tot_vendite) AS fatturato_totale
FROM
    vendite
        JOIN
    regione ON vendite.id_regione = regione.id_regione
GROUP BY regione.id_regione , data_vendita
ORDER BY data_vendita , fatturato_totale DESC;


- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? GIOCHI MOTORI; 

SELECT 
    prodotto.categoria,
    SUM(vendite.quantità_venduta) AS quantità_totale
FROM
    vendite
        JOIN
    prodotto ON vendite.id_prodotto = prodotto.id_prodotto
GROUP BY prodotto.categoria
ORDER BY quantità_totale DESC;


- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti;

INSERT INTO vendite (id_vendite, id_prodotto, id_regione, quantità_venduta, data, tot_vendite)
VALUES
  ('V021', 1, 'R01', 0, '2024-02-24', 0.00),
  ('V022', 3, 'R03', 0, '2024-02-25', 0.00),
  ('V023', 5, 'R05', 0, '2024-02-26', 0.00),
  ('V024', 8, 'R08', 0, '2024-02-27', 0.00),
  ('V025', 12, 'R12', 0, '2024-02-28', 0.00);
  
DELETE FROM vendite 
WHERE
    id_prodotto = 8;
  
SELECT 
    prodotto.id_prodotto, prodotto.nome_prodotto
FROM
    prodotto
        LEFT JOIN
    vendite ON prodotto.id_prodotto = vendite.id_prodotto
WHERE
    vendite.id_prodotto IS NULL;

SELECT 
    id_prodotto, nome_prodotto
FROM
    prodotto
WHERE
    id_prodotto NOT IN (SELECT 
            id_prodotto
        FROM
            vendite);


- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente);

SELECT 
    prodotto.id_prodotto,
    prodotto.nome_prodotto,
    MAX(vendite.data) AS ultima_data_di_vendita
FROM
    prodotto
        LEFT JOIN
    vendite ON prodotto.id_prodotto = vendite.id_prodotto
GROUP BY prodotto.id_prodotto , prodotto.nome_prodotto
ORDER BY prodotto.id_prodotto;

